package FruitEditor;

import java.awt.*;

import javax.swing.*;

public class MapListPanel extends JPanel {
	// 
}
